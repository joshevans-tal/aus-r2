// Insurance cover data
var currentCover = [
    {
        DeathCover: {
            fixedCover: 261000,
            ageBased: 50000,
            premiumBase: 34.23,
            paid: 'monthly'
        },
        tpdCover: {
            fixedCover: 121000,
            ageBased: 0,
            premiumBase: 27.23,
            paid: 'monthly'
        },
        ipCover: {
            fixedCover: 261000,
            ageBased: 0,
            premiumBase: 34.23,
            paid: 'monthly',
            "Occupation category": "light manual"
        }
    }
];