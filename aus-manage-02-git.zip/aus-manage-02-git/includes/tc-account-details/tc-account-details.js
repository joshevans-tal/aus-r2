
function createAccountDetails(id){
    var str = `
    <div class="account-details">
    <p>
    <strong>Account number: </strong>
    <span>HX36345987</span>
    </p>
    </div>`;

    return str;
}



// <div class="account-details">
// <p><span class="label">Account: </span><span>HX36345987</span></p>
// </div>