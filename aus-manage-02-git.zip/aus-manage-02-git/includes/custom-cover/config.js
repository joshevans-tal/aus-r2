export const config = {
    demo1: {
      firstName: "John",
      lastName: "Doe",
      age: 30,
    },
    demo2: {
      firstName: "Jane",
      lastName: "Doe",
      age: 25,
    },
    demo3: {
      firstName: "Bob",
      lastName: "Smith",
      age: 35,
    },
  };