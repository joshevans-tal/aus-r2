function hideShow(hideId,showId){
    let hideMe = document.getElementById(hideId);
    let showMe = document.getElementById(showId);
    showMe.style.display = "block";
    hideMe.style.display = "none";
}